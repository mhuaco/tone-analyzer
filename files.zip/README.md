# Zendesk Tone Analyzer

Matches this pipeline:

```
Zendesk (ticket created/updated/replied) -> Webhook -> FastAPI -> Zendesk API (full ticket)
  -> LLM -> Structured Analysis -> PostgreSQL
  -> [end of month] -> Monthly Job -> LLM analyzes aggregate -> Monthly Report
```

**Key design principle:** the LLM scores tone continuously, one ticket at a time, as tickets close.
The monthly job does NOT re-analyze raw transcripts -- it reads the already-scored rows from
Postgres, computes stats in plain Python (percentages, averages, trends), and sends only that
*pre-aggregated* summary to the LLM for one synthesis pass (churn-risk reasoning, common-theme
labeling). This keeps the monthly job fast and cheap regardless of ticket volume.

## Report structure (three levels)

1. **Company** -- overall tone mix, avg frustration, top problem areas. Pure computed stats, no LLM.
2. **Customer** -- per-org frustration score + trend vs prior month, churn_risk (LOW/MEDIUM/HIGH),
   product_confidence (0-10), and "why" bullets. Computed stats + LLM reasoning, merged by `org_id`.
   Orgs with fewer than `MIN_TICKETS_FOR_ORG_INSIGHT` (default 3) tickets get stats but no risk
   call -- not enough signal to avoid false positives.
3. **Product** -- per-component (e.g. "saml") ticket count, avg frustration, orgs affected, trend,
   and common_themes. Same computed-stats + LLM-reasoning merge, by component name.

This mirrors the two audiences from your original brief: customer-health rows are what you'd feed
to CS/commercial; product-health rows are what you'd feed to Product/Engineering.

## 1. Setup

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # fill in Zendesk + Anthropic + Postgres creds
```

Create the Postgres database referenced in `DATABASE_URL` (tables are created automatically on app startup).

## 2. Run the API

```bash
uvicorn app.main:app --reload --port 8000
```

Expose it publicly (e.g. `ngrok http 8000` for local testing, or deploy to Fly.io/Render/AWS/etc. for production) so Zendesk can reach it.

## 3. Configure Zendesk

**Webhook** (Admin Center -> Apps and integrations -> Webhooks -> Create webhook):
- Endpoint URL: `https://<your-domain>/webhooks/zendesk/ticket-event`
- Method: `POST`
- Request format: JSON
- Authentication: enable "Signing secret" and put the same value in `ZENDESK_WEBHOOK_SECRET` in `.env`

**Trigger** (Admin Center -> Objects and rules -> Triggers -> Add trigger):
- Conditions: choose what should fire scoring -- e.g. `Ticket: Status` is `Solved`, or `Ticket: Is` `Updated` if you want to score on every reply
- Action: `Notify webhook` -> select the webhook above
- JSON body:
```json
{
  "ticket_id": "{{ticket.id}}"
}
```

The API responds immediately and scores the ticket in a background task (fetches the full ticket + comments from Zendesk, sends to Claude, stores the structured result in `tone_analyses`).

## 4. Run the monthly job

```bash
python -m app.monthly_job
```

This aggregates the prior calendar month's `tone_analyses` rows, sends the aggregate stats (not raw transcripts) to Claude, and asks it to identify:
- **At-risk accounts** -- sustained/declining negative tone, for feeding to CS/CRM
- **Product friction** -- components with clustered negative tone across multiple accounts, for feeding to Product/Eng

Result is stored in `monthly_reports` (`report_text` is markdown, ready to paste into Slack/email/Confluence).

**Scheduling it for real:** the simplest option is a cron entry:
```
0 6 1 * * cd /path/to/project && venv/bin/python -m app.monthly_job
```
Or use the included `apscheduler` dependency to run it in-process if you'd rather not rely on system cron.

## 5. Renewal dates (optional)

If you track renewal dates as a Zendesk organization custom field, set `ZENDESK_RENEWAL_FIELD_ID`
in `.env` and adjust the field key lookup in `zendesk_client.extract_renewal_date` to match your
field's key. If renewal dates live in a CRM instead, skip this and join them onto `customer_health`
rows in `monthly_job.py` from that source -- the `org_id`/`org_name` are already there to join on.

## 6. What's NOT built yet (by design, per the validation plan)

- Routing customer_health/product_health into Slack, CRM, or Jira -- intentionally left as a manual step until the rubric and thresholds are validated by hand
- Retry/dead-letter handling on the webhook background task -- fine for a pilot, add a queue (e.g. Celery/RQ) before scaling to full ticket volume
- "Improving accounts" surfaced separately from "declining accounts" in the rendered report -- currently sorted by frustration only; easy to add once you decide whether CS wants that split out
