import httpx

from app.config import settings

BASE_URL = f"https://{settings.zendesk_subdomain}.zendesk.com/api/v2"
AUTH = (f"{settings.zendesk_email}/token", settings.zendesk_api_token)


async def get_ticket(ticket_id: int) -> dict:
    async with httpx.AsyncClient(auth=AUTH, timeout=30) as client:
        resp = await client.get(f"{BASE_URL}/tickets/{ticket_id}.json")
        resp.raise_for_status()
        return resp.json()["ticket"]


async def get_ticket_comments(ticket_id: int) -> list[dict]:
    async with httpx.AsyncClient(auth=AUTH, timeout=30) as client:
        resp = await client.get(f"{BASE_URL}/tickets/{ticket_id}/comments.json")
        resp.raise_for_status()
        return resp.json()["comments"]


def build_transcript(ticket: dict, comments: list[dict]) -> str:
    """Flatten ticket + comments into a readable transcript for the LLM.
    Keeps public comments only by default (skip internal agent notes) so we're
    scoring customer-facing exchanges, not internal agent chatter.
    """
    lines = [f"Subject: {ticket.get('subject', '(no subject)')}"]
    for c in comments:
        if not c.get("public", True):
            continue
        author = "Agent" if c.get("via", {}).get("channel") == "web" and c.get("author_id") == ticket.get("assignee_id") else "Customer"
        lines.append(f"[{author}]: {c.get('plain_body', c.get('body', ''))}")
    return "\n\n".join(lines)


async def get_organization(org_id: int) -> dict:
    async with httpx.AsyncClient(auth=AUTH, timeout=30) as client:
        resp = await client.get(f"{BASE_URL}/organizations/{org_id}.json")
        resp.raise_for_status()
        return resp.json()["organization"]


def extract_renewal_date(organization: dict) -> str | None:
    """Pulls a renewal date from an org custom field, if ZENDESK_RENEWAL_FIELD_ID is configured.
    Returns an ISO date string or None. If you track renewal dates in a CRM instead, skip this
    and join renewal dates onto customer_health in the monthly job from that source."""
    if not settings.zendesk_renewal_field_id:
        return None
    fields = organization.get("organization_fields") or {}
    # Zendesk custom org fields are keyed by field key, not id, in the API response --
    # if your field key differs, adjust this lookup accordingly.
    return fields.get("renewal_date")


async def update_ticket_field(ticket_id: int, custom_field_id: int, value) -> None:
    """Write the tone score back onto the ticket as a custom field, so agents see it in-ticket."""
    payload = {"ticket": {"custom_fields": [{"id": custom_field_id, "value": value}]}}
    async with httpx.AsyncClient(auth=AUTH, timeout=30) as client:
        resp = await client.put(f"{BASE_URL}/tickets/{ticket_id}.json", json=payload)
        resp.raise_for_status()
