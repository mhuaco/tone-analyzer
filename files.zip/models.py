from datetime import datetime

from sqlalchemy import (
    Column,
    DateTime,
    Float,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)

from app.database import Base


class ToneAnalysis(Base):
    """One row per Zendesk ticket that has been scored. This is the continuous per-ticket
    layer -- the monthly job reads from this table rather than re-analyzing raw transcripts."""

    __tablename__ = "tone_analyses"

    id = Column(Integer, primary_key=True)
    ticket_id = Column(Integer, nullable=False)

    org_id = Column(Integer, nullable=True, index=True)
    org_name = Column(String, nullable=True)
    org_renewal_date = Column(DateTime, nullable=True)  # optional, see config.zendesk_renewal_field_id

    requester_id = Column(Integer, nullable=True)
    assignee_id = Column(Integer, nullable=True)

    ticket_status = Column(String, nullable=True)
    ticket_subject = Column(String, nullable=True)
    ticket_created_at = Column(DateTime, nullable=True)

    # --- LLM output ---
    frustration_score = Column(Float, nullable=False)  # 0 (delighted) to 10 (extremely frustrated/angry)
    tone_category = Column(String, nullable=False)  # positive | neutral | frustrated | angry
    component_tags = Column(JSON, nullable=False, default=list)  # e.g. ["saml", "authentication"]
    key_signals = Column(JSON, nullable=False, default=list)  # short excerpts/paraphrases supporting the score
    confidence = Column(Float, nullable=False)
    summary = Column(Text, nullable=True)

    analyzed_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (UniqueConstraint("ticket_id", name="uq_ticket_id"),)


class MonthlyReport(Base):
    """One row per monthly rollup run. Stores all three report levels
    (company / customer / product) as JSON plus the rendered narrative."""

    __tablename__ = "monthly_reports"

    id = Column(Integer, primary_key=True)

    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)

    company_stats = Column(JSON, nullable=False)  # overall tone %, avg frustration, top problem areas
    customer_health = Column(JSON, nullable=False, default=list)  # per-org: stats + churn_risk + why
    product_health = Column(JSON, nullable=False, default=list)  # per-component: stats + common_themes

    report_text = Column(Text, nullable=False)  # full rendered report

    generated_at = Column(DateTime, default=datetime.utcnow)
