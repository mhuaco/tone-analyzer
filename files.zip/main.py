import hashlib
import hmac
import base64
from datetime import datetime

from fastapi import BackgroundTasks, Depends, FastAPI, Header, HTTPException, Request
from sqlalchemy.orm import Session

from app.config import settings
from app.database import Base, engine, get_db
from app.llm_analyzer import analyze_ticket_tone
from app.models import ToneAnalysis
from app.zendesk_client import (
    build_transcript,
    extract_renewal_date,
    get_organization,
    get_ticket,
    get_ticket_comments,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Zendesk Tone Analyzer")


def verify_zendesk_signature(body: bytes, signature: str | None, timestamp: str | None) -> bool:
    """Verify Zendesk's webhook signing header. See Zendesk docs for 'Webhook signing secret'."""
    if not settings.zendesk_webhook_secret:
        return True  # signing not configured -- fine for local dev, do this before prod
    if not signature or not timestamp:
        return False
    message = timestamp.encode() + body
    expected = base64.b64encode(
        hmac.new(settings.zendesk_webhook_secret.encode(), message, hashlib.sha256).digest()
    ).decode()
    return hmac.compare_digest(expected, signature)


async def process_ticket(ticket_id: int, db: Session) -> None:
    ticket = await get_ticket(ticket_id)
    comments = await get_ticket_comments(ticket_id)
    transcript = build_transcript(ticket, comments)

    result = analyze_ticket_tone(transcript)

    org_id = ticket.get("organization_id")
    org_name = None
    org_renewal_date = None
    if org_id:
        try:
            org = await get_organization(org_id)
            org_name = org.get("name")
            renewal_str = extract_renewal_date(org)
            org_renewal_date = datetime.fromisoformat(renewal_str) if renewal_str else None
        except Exception:
            pass  # don't fail ticket scoring just because org lookup hiccuped

    existing = db.query(ToneAnalysis).filter_by(ticket_id=ticket_id).first()
    row = existing or ToneAnalysis(ticket_id=ticket_id)
    row.org_id = org_id
    row.org_name = org_name
    row.org_renewal_date = org_renewal_date
    row.requester_id = ticket.get("requester_id")
    row.assignee_id = ticket.get("assignee_id")
    row.ticket_status = ticket.get("status")
    row.ticket_subject = ticket.get("subject")
    row.ticket_created_at = (
        datetime.fromisoformat(ticket["created_at"].replace("Z", "+00:00")) if ticket.get("created_at") else None
    )
    row.frustration_score = result.frustration_score
    row.tone_category = result.tone_category
    row.component_tags = result.component_tags
    row.key_signals = result.key_signals
    row.confidence = result.confidence
    row.summary = result.summary
    row.analyzed_at = datetime.utcnow()

    if not existing:
        db.add(row)
    db.commit()


@app.post("/webhooks/zendesk/ticket-event")
async def zendesk_ticket_event(
    request: Request,
    background_tasks: BackgroundTasks,
    x_zendesk_webhook_signature: str | None = Header(default=None),
    x_zendesk_webhook_signature_timestamp: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    body = await request.body()
    if not verify_zendesk_signature(body, x_zendesk_webhook_signature, x_zendesk_webhook_signature_timestamp):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    payload = await request.json()
    ticket_id = payload.get("ticket_id") or payload.get("id")
    if not ticket_id:
        raise HTTPException(status_code=400, detail="No ticket_id in payload")

    # Run the fetch + LLM scoring after responding, so Zendesk's webhook doesn't time out.
    background_tasks.add_task(process_ticket, int(ticket_id), db)
    return {"status": "accepted", "ticket_id": ticket_id}


@app.get("/health")
def health():
    return {"status": "ok"}
