from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    zendesk_subdomain: str
    zendesk_email: str
    zendesk_api_token: str
    zendesk_webhook_secret: str | None = None
    # Optional: Zendesk organization custom field ID holding renewal date, if you track it there.
    # Otherwise pull renewal dates from your CRM and join in the monthly job instead.
    zendesk_renewal_field_id: int | None = None

    anthropic_api_key: str
    llm_model: str = "claude-sonnet-5"

    database_url: str

    class Config:
        env_file = ".env"


settings = Settings()
